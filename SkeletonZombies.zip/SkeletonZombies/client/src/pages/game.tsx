import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Skull, Trophy, RefreshCw } from 'lucide-react';
import skeletonSprite from '@assets/generated_images/pixel_art_skeleton_warrior_with_white_outline.png';
import zombieSprite from '@assets/generated_images/pixel_art_zombie_sprite.png';
import bigZombieSprite from '@assets/generated_images/pixel_art_big_scary_zombie_sprite.png';
import hugeZombieSprite from '@assets/generated_images/pixel_art_huge_terrifying_zombie_boss_sprite.png';
import bgImage from '@assets/generated_images/pixel_art_graveyard_background.png';
import { Joystick } from 'react-joystick-component';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';

// --- Game Constants ---
const GAME_WIDTH = 800;
const GAME_HEIGHT = 400;
const SPAWN_RATE_MS = 2000;
const ZOMBIE_SPEED_MS = 5000; // Time to cross screen
const ATTACK_RANGE = 400;
const DAMAGE_PER_CLICK = 35;
const ZOMBIE_HP_NORMAL = 100;
const ZOMBIE_HP_BIG = 200;
const ZOMBIE_HP_HUGE = 500;
const PLAYER_HP = 100;
const PLAYER_SPEED = 200; // Pixels per second

// --- Types ---
type ZombieType = 'normal' | 'big' | 'huge';

interface Entity {
  id: string;
  x: number;
  hp: number;
  maxHp: number;
  type: ZombieType;
  state: 'walking' | 'dying' | 'attacking';
}

// --- Components ---

const HealthBar = ({ current, max, color = "bg-red-500" }: { current: number, max: number, color?: string }) => (
  <div className="w-16 h-2 bg-black/50 border border-white/20 relative overflow-hidden">
    <div 
      className={`h-full ${color} transition-all duration-200`} 
      style={{ width: `${Math.max(0, (current / max) * 100)}%` }}
    />
  </div>
);

const DamageNumber = ({ x, y, value }: { x: number, y: number, value: number }) => (
  <motion.div
    initial={{ opacity: 1, y: 0, scale: 0.5 }}
    animate={{ opacity: 0, y: -50, scale: 1.5 }}
    exit={{ opacity: 0 }}
    className="absolute text-white font-pixel text-xl font-bold z-50 pointer-events-none"
    style={{ left: x, top: y, textShadow: '2px 2px 0 #000' }}
  >
    {value}
  </motion.div>
);

export default function Game() {
  const [gameState, setGameState] = useState<'start' | 'playing' | 'gameover'>('start');
  const [score, setScore] = useState(0);
  const [playerHp, setPlayerHp] = useState(PLAYER_HP);
  const [playerX, setPlayerX] = useState(100);
  const [zombies, setZombies] = useState<Entity[]>([]);
  const [lastSpawn, setLastSpawn] = useState(0);
  const [damageNumbers, setDamageNumbers] = useState<{id: string, x: number, y: number, val: number}[]>([]);
  const [isAttacking, setIsAttacking] = useState(false);
  
  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const joystickX = useRef(0);
  const gameAreaRef = useRef<HTMLDivElement>(null);

  const handleJoystickMove = (event: IJoystickUpdateEvent) => {
    if (event.x) joystickX.current = event.x;
  };

  const handleJoystickStop = () => {
    joystickX.current = 0;
  };

  // Input Handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { keysPressed.current[e.key] = true; };
    const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game Loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    let animationFrameId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const delta = time - lastTime;
      lastTime = time;

      // Update Player Position
      setPlayerX(prevX => {
        let newX = prevX;
        if (keysPressed.current['ArrowLeft'] || keysPressed.current['a']) {
          newX -= (PLAYER_SPEED * delta) / 1000;
        }
        if (keysPressed.current['ArrowRight'] || keysPressed.current['d']) {
          newX += (PLAYER_SPEED * delta) / 1000;
        }
        
        // Joystick Movement
        if (Math.abs(joystickX.current) > 0.1) {
          newX += (PLAYER_SPEED * delta * joystickX.current) / 1000;
        }

        // Clamp to screen bounds (left side: 50, right side: GAME_WIDTH - 50)
        return Math.max(50, Math.min(GAME_WIDTH - 50, newX));
      });

      // Spawn Zombies
      const level = Math.floor(score / 1000);
      const currentSpawnRate = level === 0 ? SPAWN_RATE_MS : 500 / Math.pow(2, level - 1);

      if (time - lastSpawn > currentSpawnRate) {
        spawnZombie();
        setLastSpawn(time);
      }

      // Update Zombies
      setZombies(prev => {
        const next = prev.map(z => {
          // Move zombie left
          const newX = z.x - (GAME_WIDTH / ZOMBIE_SPEED_MS) * delta;
          
          // Check collision with player (using dynamic playerX)
          // Simple box collision: if zombie gets close enough to playerX
          if (Math.abs(newX - playerX) < 50 && z.state !== 'dying') {
             // Zombie hit player
             setPlayerHp(hp => Math.max(0, hp - 0.5)); // Drain HP slowly on contact
             return { ...z, x: newX, state: 'attacking' as const };
          }
          
          return { ...z, x: newX };
        }).filter(z => z.hp > 0); // Remove dead ones immediately? Or animation?
        
        return next;
      });

      if (playerHp <= 0) {
        setGameState('gameover');
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [gameState, lastSpawn, playerHp, playerX]);

  const spawnZombie = () => {
    const id = Math.random().toString(36).substr(2, 9);
    const rand = Math.random();
    let type: ZombieType = 'normal';
    let hp = ZOMBIE_HP_NORMAL;

    if (rand > 0.9) {
      type = 'huge';
      hp = ZOMBIE_HP_HUGE;
    } else if (rand > 0.7) {
      type = 'big';
      hp = ZOMBIE_HP_BIG;
    }

    setZombies(prev => [
      ...prev, 
      { 
        id, 
        x: GAME_WIDTH, 
        hp, 
        maxHp: hp,
        type,
        state: 'walking' 
      }
    ]);
  };

  const handleAttack = () => {
    if (gameState !== 'playing') return;
    
    setIsAttacking(true);
    setTimeout(() => setIsAttacking(false), 200); // Reset attack anim

    // Hit closest zombie within range
    const hitZombies = zombies.filter(z => Math.abs(z.x - playerX) < ATTACK_RANGE && z.x > playerX - 50);
    
    if (hitZombies.length > 0) {
      // Play sound effect logic here
      
      setZombies(prev => prev.map(z => {
        if (hitZombies.find(hz => hz.id === z.id)) {
          const newHp = z.hp - DAMAGE_PER_CLICK;
          
          // Show damage number
          addDamageNumber(z.x + 20, 200, DAMAGE_PER_CLICK);
          
          if (newHp <= 0) {
            setScore(s => s + 100);
          }
          return { ...z, hp: newHp };
        }
        return z;
      }));
    }
  };

  const addDamageNumber = (x: number, y: number, val: number) => {
    const id = Math.random().toString();
    setDamageNumbers(prev => [...prev, { id, x, y, val }]);
    setTimeout(() => {
      setDamageNumbers(prev => prev.filter(d => d.id !== id));
    }, 1000);
  };

  const startGame = () => {
    setGameState('playing');
    setScore(0);
    setPlayerHp(PLAYER_HP);
    setZombies([]);
    setLastSpawn(performance.now());
  };

  return (
    <div className="w-full h-screen bg-black flex items-center justify-center overflow-hidden font-pixel relative">
      
      {/* Effects Overlays */}
      <div className="scanlines z-50 pointer-events-none" />
      <div className="vignette z-40 pointer-events-none" />
      
      {/* Game Container */}
      <div 
        ref={gameAreaRef}
        className="relative w-full max-w-4xl aspect-video bg-[#1a0b2e] overflow-hidden border-4 border-white/10 shadow-2xl cursor-crosshair"
        onClick={handleAttack}
      >
        {/* Background */}
        <div 
          className="absolute inset-0 z-0 opacity-80"
          style={{
            backgroundImage: `url(${bgImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            imageRendering: 'pixelated'
          }}
        />
        
        {/* Mist Layer (Parallax-ish) */}
        <div className="absolute inset-0 bg-gradient-to-t from-purple-900/40 to-transparent z-10 bottom-0 h-1/2" />

        {/* UI HUD */}
        <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start z-50">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-primary drop-shadow-md">
              <Heart className="fill-primary" size={24} />
              <span className="text-xl">HP</span>
            </div>
            <Progress value={(playerHp / PLAYER_HP) * 100} className="w-48 h-4 bg-black border-2 border-white/20" />
          </div>

          <div className="flex flex-col items-end gap-2">
             <div className="flex items-center gap-2 text-accent drop-shadow-md">
              <Trophy className="fill-accent" size={24} />
              <span className="text-2xl">{score.toString().padStart(6, '0')}</span>
            </div>
          </div>
        </div>

        {/* Game World */}
        <div className="absolute inset-0 flex items-end pb-16 px-16 z-20">
          
          {/* Player (Skeleton) */}
          <motion.div 
            className="absolute bottom-16 w-24 h-24 z-30"
            style={{ left: playerX }}
            animate={{ 
              scale: isAttacking ? [2.0, 2.2, 2.0] : 2.0,
              rotate: isAttacking ? [0, -10, 20, 0] : 0
            }}
            transition={{ duration: 0.1 }}
          >
            {/* Attack Swipe Effect */}
            <AnimatePresence>
              {isAttacking && (
                <motion.div 
                  initial={{ opacity: 0, x: 0, width: 0 }}
                  animate={{ opacity: 1, x: 60, width: 90 }}
                  exit={{ opacity: 0 }}
                  className="absolute top-8 left-16 h-1 bg-white shadow-[0_0_8px_white] rotate-[10deg]"
                />
              )}
            </AnimatePresence>

            <img 
              src={skeletonSprite} 
              alt="Skeleton" 
              className="w-full h-full object-contain drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)]"
              style={{ imageRendering: 'pixelated', mixBlendMode: 'lighten', transform: 'scaleX(-1)' }} 
            />
            {/* Ground Shadow */}
            <div className="absolute -bottom-2 left-4 right-4 h-4 bg-black/50 blur-sm rounded-full" />
          </motion.div>

          {/* Zombies */}
          <AnimatePresence>
            {zombies.map(zombie => (
              <motion.div
                key={zombie.id}
                initial={{ x: GAME_WIDTH, opacity: 0 }}
                animate={{ x: zombie.x, opacity: 1 }}
                exit={{ opacity: 0, scale: 0, rotate: 90 }}
                className={`absolute bottom-16 ${
                  zombie.type === 'huge' ? 'w-48 h-48 -mb-8' : 
                  zombie.type === 'big' ? 'w-40 h-40 -mb-4' : 
                  'w-32 h-32'
                }`}
                style={{ left: 0 }} // Position controlled by framer motion animate x
              >
                <div className="absolute -top-8 left-0 right-0 flex justify-center">
                  <HealthBar current={zombie.hp} max={zombie.maxHp} />
                </div>
                <img 
                  src={
                    zombie.type === 'huge' ? hugeZombieSprite :
                    zombie.type === 'big' ? bigZombieSprite :
                    zombieSprite
                  } 
                  alt="Zombie" 
                  className="w-full h-full object-contain grayscale-[0.2] hover:grayscale-0 transition-all"
                  style={{ 
                    imageRendering: 'pixelated',
                    transform: zombie.type === 'normal' ? 'scaleX(1)' : 'scaleX(-1)' // Flip big/huge ones
                  }} 
                />
                <div className="absolute -bottom-2 left-8 right-8 h-4 bg-black/50 blur-sm rounded-full" />
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Damage Numbers */}
          <AnimatePresence>
            {damageNumbers.map(dn => (
              <DamageNumber key={dn.id} x={dn.x} y={dn.y} value={dn.val} />
            ))}
          </AnimatePresence>

        </div>

        {/* Overlays: Start / Game Over */}
        {gameState === 'start' && (
          <div className="absolute inset-0 bg-black/80 z-50 flex flex-col items-center justify-center text-center space-y-8">
            <h1 className="text-6xl text-primary animate-pulse drop-shadow-[0_0_15px_rgba(0,255,0,0.5)]">
              BONE DEFENSE
            </h1>
            <p className="text-white/60 text-xl font-retro max-w-md">
              Click to slash the incoming horde. protect the crypt at all costs.
            </p>
            <Button 
              onClick={startGame}
              size="lg" 
              className="text-2xl px-12 py-8 bg-accent text-accent-foreground hover:bg-white hover:scale-105 transition-all border-4 border-transparent hover:border-accent"
            >
              START BATTLE
            </Button>
          </div>
        )}

        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-red-900/90 z-50 flex flex-col items-center justify-center text-center space-y-8">
            <h1 className="text-6xl text-white drop-shadow-[4px_4px_0_#000]">GAME OVER</h1>
            <div className="text-2xl text-accent">SCORE: {score}</div>
            <Button 
              onClick={startGame}
              size="lg" 
              className="gap-4 text-xl px-8 py-6 bg-white text-black hover:bg-gray-200"
            >
              <RefreshCw size={24} /> TRY AGAIN
            </Button>
          </div>
        )}

      </div>

      {/* Instructions Footer */}
      <div className="absolute bottom-8 text-white/30 text-sm font-retro">
        PROTOTYPE v0.1 • CLICK TO ATTACK • PROTECT THE SKELETON
      </div>

      {/* Virtual Joystick */}
      <div className="absolute bottom-8 left-8 z-50 opacity-50 hover:opacity-100 transition-opacity">
        <Joystick 
          size={100} 
          sticky={false} 
          baseColor="rgba(255, 255, 255, 0.1)" 
          stickColor="rgba(255, 255, 255, 0.5)" 
          move={handleJoystickMove} 
          stop={handleJoystickStop} 
        />
      </div>
    </div>
  );
}
